#ifndef _INTERNAL_ATOMIC_H
#define _INTERNAL_ATOMIC_H


#endif
