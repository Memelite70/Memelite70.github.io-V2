#ifndef LANGINFO_H
#define LANGINFO_H

#include "../../include/langinfo.h"

char *__nl_langinfo_l(nl_item, locale_t);

#endif
