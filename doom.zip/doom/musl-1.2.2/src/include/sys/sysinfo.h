#ifndef SYS_SYSINFO_H
#define SYS_SYSINFO_H

#include "../../../include/sys/sysinfo.h"
#include <features.h>

hidden int __lsysinfo(struct sysinfo *);

#endif
