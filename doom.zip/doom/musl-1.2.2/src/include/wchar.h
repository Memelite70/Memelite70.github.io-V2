#ifndef WCHAR_H
#define WCHAR_H

#define __DEFINED_struct__IO_FILE

#include "../../include/wchar.h"

#endif

