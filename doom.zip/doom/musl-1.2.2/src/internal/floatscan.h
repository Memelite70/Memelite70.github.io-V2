#ifndef FLOATSCAN_H
#define FLOATSCAN_H

#include <stdio.h>

hidden long double __floatscan(FILE *, int, int);

#endif
