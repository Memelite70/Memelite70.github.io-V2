#include "version.h"
#include "libc.h"

const char __libc_version[] = VERSION;
