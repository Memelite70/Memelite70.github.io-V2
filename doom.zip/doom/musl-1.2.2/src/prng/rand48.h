#include <stdint.h>
#include <features.h>

hidden uint64_t __rand48_step(unsigned short *xi, unsigned short *lc);
extern hidden unsigned short __seed48[7];
